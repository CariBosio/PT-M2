This template / effect / code has been created by Cooper.
You can customize and check it out on its original site on the following link:
https://codepen.io/cooper5/pen/eYNgLoJ

Thank you